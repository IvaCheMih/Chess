//go:build google_cloud_storage
// +build google_cloud_storage

package cli

import (
	_ "github.com/golang-migrate/migrate/v4/source/google_cloud_storage"
)
