CREATE TABLE pets (
  name string
);