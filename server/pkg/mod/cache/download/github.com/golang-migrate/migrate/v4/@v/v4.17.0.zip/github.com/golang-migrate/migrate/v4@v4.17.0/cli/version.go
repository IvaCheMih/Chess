package main

// Version is set in Makefile with build flags
var Version = "dev"
