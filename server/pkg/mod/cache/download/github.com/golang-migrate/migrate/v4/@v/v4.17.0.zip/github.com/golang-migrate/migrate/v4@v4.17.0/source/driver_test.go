package source

func ExampleDriver() {
	// see source/stub for an example

	// source/stub/stub.go has the driver implementation
	// source/stub/stub_test.go runs source/testing/test.go:Test
}
