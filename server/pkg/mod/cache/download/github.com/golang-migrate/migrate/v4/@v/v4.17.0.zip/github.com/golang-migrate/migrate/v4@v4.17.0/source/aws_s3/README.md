# aws_s3

`s3://<bucket>/<prefix>`
