CREATE TABLE test_2 (
    Date Date 
) Engine=Memory;